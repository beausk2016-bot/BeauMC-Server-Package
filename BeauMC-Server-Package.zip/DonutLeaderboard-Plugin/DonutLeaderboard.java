package dev.serverboard.donut;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class DonutLeaderboard extends JavaPlugin implements Listener {
    private Economy economy;
    private final DecimalFormat moneyFormat = new DecimalFormat("#,##0.##");

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        setupEconomy();
        loadKnownPlayers();
        long interval = Math.max(20L, getConfig().getLong("sidebar.refresh-ticks", 40L));
        Bukkit.getScheduler().runTaskTimer(this, this::refreshAll, 1L, interval);
        getLogger().info(economy == null
                ? "Vault economy not found; money will show as unavailable until an economy provider is installed."
                : "Vault economy connected.");
    }

    @Override
    public void onDisable() {
        saveConfig();
    }

    private boolean setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> provider = Bukkit.getServicesManager().getRegistration(Economy.class);
        if (provider == null) return false;
        economy = provider.getProvider();
        return economy != null;
    }

    private void loadKnownPlayers() {
        for (String raw : getConfig().getStringList("known-players")) {
            try {
                UUID id = UUID.fromString(raw);
                getConfig().addDefault("player-data." + id + ".kills", 0);
                getConfig().addDefault("player-data." + id + ".deaths", 0);
                getConfig().addDefault("player-data." + id + ".shards", getConfig().getInt("stats.default-shards", 0));
                getConfig().addDefault("player-data." + id + ".keyall", getConfig().getString("stats.default-keyall", "N/A"));
                getConfig().addDefault("player-data." + id + ".team", getConfig().getString("stats.default-team", "None"));
                getConfig().addDefault("player-data." + id + ".playtime-seconds", 0L);
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("Ignoring invalid UUID in known-players: " + raw);
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String path = "player-data." + player.getUniqueId();
        List<String> known = getConfig().getStringList("known-players");
        String id = player.getUniqueId().toString();
        if (!known.contains(id)) {
            known.add(id);
            getConfig().set("known-players", known);
        }
        getConfig().addDefault(path + ".name", player.getName());
        getConfig().addDefault(path + ".kills", 0);
        getConfig().addDefault(path + ".deaths", 0);
        getConfig().addDefault(path + ".shards", getConfig().getInt("stats.default-shards", 0));
        getConfig().addDefault(path + ".keyall", getConfig().getString("stats.default-keyall", "N/A"));
        getConfig().addDefault(path + ".team", getConfig().getString("stats.default-team", "None"));
        getConfig().addDefault(path + ".playtime-seconds", 0L);
        getConfig().set(path + ".name", player.getName());
        getConfig().set(path + ".session-start", System.currentTimeMillis() / 1000L);
        getConfig().options().copyDefaults(true);
        if (getConfig().getBoolean("sidebar.default-enabled", true)) showSidebar(player);
        saveConfig();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        increment(event.getEntity(), "deaths", 1);
        Player killer = event.getEntity().getKiller();
        if (killer != null) increment(killer, "kills", 1);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        addSessionTime(player);
        player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        saveConfig();
    }

    private void increment(Player player, String key, int amount) {
        String path = playerPath(player) + "." + key;
        getConfig().set(path, getConfig().getInt(path, 0) + amount);
    }

    private void addSessionTime(Player player) {
        String path = playerPath(player) + ".playtime-seconds";
        long joinedAt = getConfig().getLong(playerPath(player) + ".session-start", System.currentTimeMillis() / 1000L);
        long elapsed = Math.max(0L, System.currentTimeMillis() / 1000L - joinedAt);
        getConfig().set(path, getConfig().getLong(path, 0L) + elapsed);
        getConfig().set(playerPath(player) + ".session-start", System.currentTimeMillis() / 1000L);
    }

    private String playerPath(Player player) {
        return "player-data." + player.getUniqueId();
    }

    private void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            long last = getConfig().getLong(playerPath(player) + ".session-start", System.currentTimeMillis() / 1000L);
            long current = getConfig().getLong(playerPath(player) + ".playtime-seconds", 0L);
            long elapsed = Math.max(0L, System.currentTimeMillis() / 1000L - last);
            updateSidebar(player, current + elapsed);
        }
    }

    private void showSidebar(Player player) {
        updateSidebar(player, getConfig().getLong(playerPath(player) + ".playtime-seconds", 0L));
    }

    private void updateSidebar(Player player, long playSeconds) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = board.registerNewObjective("donutstats", "dummy", color(getConfig().getString("sidebar.title", "&b&lBeauMC")));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        List<String> configured = getConfig().getStringList("sidebar.lines");
        List<String> lines = configured.isEmpty() ? List.of("&a$ &fMoney: &a{money}", "&c⚔ &fKills: &c{kills}", "&6☠ &fDeaths: &6{deaths}") : configured;
        int score = lines.size();
        int index = 0;
        for (String template : lines) {
            String text = render(template, player, playSeconds);
            String entry = uniqueEntry(board, color(text), index++);
            Team team = board.registerNewTeam("line" + index);
            team.addEntry(entry);
            objective.getScore(entry).setScore(score--);
        }
        player.setScoreboard(board);
    }

    private String uniqueEntry(Scoreboard board, String text, int index) {
        String entry = text.length() > 40 ? text.substring(0, 40) : text;
        while (board.getEntries().contains(entry)) entry += ChatColor.values()[index++ % ChatColor.values().length];
        return entry;
    }

    private String render(String template, Player player, long playSeconds) {
        String base = playerPath(player);
        double balance = economy == null ? Double.NaN : economy.getBalance((OfflinePlayer) player);
        String money = Double.isNaN(balance) ? "N/A" : getConfig().getString("sidebar.currency-symbol", "$") + moneyFormat.format(balance);
        return template.replace("{money}", money)
                .replace("{shards}", Integer.toString(getConfig().getInt(base + ".shards", 0)))
                .replace("{kills}", Integer.toString(getConfig().getInt(base + ".kills", 0)))
                .replace("{deaths}", Integer.toString(getConfig().getInt(base + ".deaths", 0)))
                .replace("{keyall}", getConfig().getString(base + ".keyall", "N/A"))
                .replace("{session}", formatSessionDuration(Math.max(0L, System.currentTimeMillis() / 1000L
                        - getConfig().getLong(base + ".session-start", System.currentTimeMillis() / 1000L))))
                .replace("{team}", getConfig().getString(base + ".team", "None"))
                .replace("{playtime}", formatDuration(playSeconds))
                .replace("{ping}", Integer.toString(Math.max(0, player.getPing())));
    }

    private String formatDuration(long totalSeconds) {
        long days = totalSeconds / 86400;
        long hours = (totalSeconds % 86400) / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        if (days > 0) return days + "d " + hours + "h";
        if (hours > 0) return hours + "h " + minutes + "m";
        return minutes + "m";
    }

    private String formatSessionDuration(long totalSeconds) {
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;
        return String.format(Locale.ROOT, "%02d:%02d:%02d", hours, minutes, seconds);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("leaderboard")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("This command is for players.");
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("off")) {
                player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
                player.sendMessage(color("&7Stats sidebar hidden."));
            } else {
                showSidebar(player);
                player.sendMessage(color("&aStats sidebar enabled."));
            }
            return true;
        }
        if (command.getName().equalsIgnoreCase("lbadmin")) return adminCommand(sender, args);
        return false;
    }

    private boolean adminCommand(CommandSender sender, String[] args) {
        if (!sender.hasPermission("donutleaderboard.admin")) {
            sender.sendMessage(color("&cYou don't have permission."));
            return true;
        }
        if (args.length < 3) return false;
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        String path = "player-data." + target.getUniqueId();
        String value = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "setshards" -> {
                try { getConfig().set(path + ".shards", Math.max(0, Integer.parseInt(value))); }
                catch (NumberFormatException e) { sender.sendMessage(color("&cShard amount must be a whole number.")); return true; }
            }
            case "setteam" -> getConfig().set(path + ".team", value);
            default -> { return false; }
        }
        List<String> known = getConfig().getStringList("known-players");
        String uuid = target.getUniqueId().toString();
        if (!known.contains(uuid)) known.add(uuid);
        getConfig().set("known-players", known);
        getConfig().set(path + ".name", target.getName() == null ? args[1] : target.getName());
        saveConfig();
        if (target.isOnline()) updateSidebar(target.getPlayer(), getConfig().getLong(path + ".playtime-seconds", 0L));
        sender.sendMessage(color("&aUpdated " + args[1] + "'s " + args[0] + "."));
        return true;
    }
}
