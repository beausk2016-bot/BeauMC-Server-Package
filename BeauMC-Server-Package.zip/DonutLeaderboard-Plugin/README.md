# DonutLeaderboard

A Paper plugin that displays a Donut-style personal stats sidebar like the attached screenshot. It reads the player's balance through Vault, tracks kills, deaths, and playtime, and allows staff to set shard, Keyall, and team labels.

## Requirements

- Paper 1.21.4 (or a compatible 1.21 server) running Java 21
- Vault and an economy provider registered with Vault (for example, EssentialsX Economy)

DonutShop's `prices` values are item purchase prices. The plugin includes the supplied prices as reference values in `config.yml`; they do not mint money. The displayed money comes from the shared Vault economy, so DonutShop purchases and deposits from your economy provider are reflected automatically.

## Build and install

Run `mvn package`, then copy `target/DonutLeaderboard.jar` into the server's `plugins` folder. Start the server once to create `plugins/DonutLeaderboard/config.yml`.

## Commands

- `/leaderboard` or `/lb`: show the sidebar
- `/leaderboard off`: hide it for yourself
- `/lbadmin setshards <player> <amount>`
- `/lbadmin setteam <player> <text>`

The Session row counts up while the player is online; Playtime shows saved accumulated time. Edit `sidebar.lines` in config to change the order or wording. Available placeholders: `{money}`, `{shards}`, `{kills}`, `{deaths}`, `{session}`, `{playtime}`, `{team}`, and `{ping}`.
