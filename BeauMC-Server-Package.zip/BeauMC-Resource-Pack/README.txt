BeauMC Resource Pack
====================

Minecraft Java Edition 1.21.4 resource pack. It adds eight custom pixel icons used by the BeauMC leaderboard sidebar.

Install for your own client:
1. Copy BeauMC-Resource-Pack.zip into .minecraft/resourcepacks.
2. Enable "BeauMC Sidebar Icons" under Options > Resource Packs.

Server distribution:
Host the ZIP on a direct-download HTTPS URL and configure the server's resource-pack URL/hash in server.properties. Players must enable/download the pack to see the icons.

The companion DonutLeaderboard Paper plugin is still required for live balance, kills, playtime, and team values. A resource pack changes visuals; it cannot read server economy or player statistics by itself.
